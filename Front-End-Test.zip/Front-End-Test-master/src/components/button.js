import React from "react";

const ButtonComponent = props => {
  return <button class="button_delete">Delete</button>;
};

export default ButtonComponent;
